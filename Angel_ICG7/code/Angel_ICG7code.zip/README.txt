This code directory contains files downloaded from http://www.cs.unm.edu/~angel/BOOK/INTERACTIVE_COMPUTER_GRAPHICS/SEVENTH_EDITION/CODE/ and up-to-date as of 15 Jun 2015, consisting of subdirectories:
* ch02 - Chapter 2 programs
* ch03 - Chapter 3 programs
* ch04 - Chapter 4 programs
* ch05 - Chapter 5 programs
* CLASS - A miscellany of programs being variations on the chapter example programs, perhaps used in class teaching.
* Common - Utilities, a matrix/vector class package and shader initialisation functions.

Each subdirectory has a zip file containing the files of that directory.
This directory has a zip file containining all the other zip files.